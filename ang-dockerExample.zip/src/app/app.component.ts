import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title : string = 'Calculator App';
  fValue : number = 0;
  sValue : number = 0;
  result : number = 0;
  operand : string = "";

  getResult(){
    switch(this.operand){
      case "+" : this.result = this.fValue + this.sValue; break; 
      case "-" : this.result = this.fValue - this.sValue; break; 
      case "X" : this.result = this.fValue * this.sValue; break; 
      case "/" : this.result = this.fValue / this.sValue; break;
      default : this.result = 0; break; 
    }  
  }
}
