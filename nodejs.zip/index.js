/*
open the terminal:
npm init -y: create a default package.json. 
npm install --save express: installs express local to the folder...
create index.js file and write the below code
node index.js will run the express and test it thru' browser:
*/
const app = require("express")();
const parser = require("body-parser");

const data = [];

app.use(parser.urlencoded({"extended" : true}));
app.use(parser.json());

const func = () =>{

    let emp = {};
    emp.empid = 123;
    emp.empName ="Phaniraj";
    emp.empAddress ="BLR";
    data.push(emp);
    
    data.push({"empId" : 123, "empName" : "Phaniraj", "empAddress" : "BLR"});    
    data.push({"empId" : 124, "empName" : "Rajesh", "empAddress" : "MYS"});    
    data.push({"empId" : 125, "empName" : "Albert", "empAddress" : "UBL"});    
    data.push({"empId" : 126, "empName" : "Steven", "empAddress" : "DEL"});    
    return data;
}
app.listen(3000);

app.get("/", (req, res)=>{
    const data = func();
    res.send(data);
})

app.post("/", (req, res)=>{
    const input = req.body;//thru body-parser we get the data posted by the user...
    data.push(input);
    res.send("Data is inserted");
})